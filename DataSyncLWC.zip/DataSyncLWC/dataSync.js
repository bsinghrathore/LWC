import { LightningElement } from 'lwc';
import  makeGetCallout from '@salesforce/apex/ProjectClass.makeGetCallout';

export default class DataSync extends LightningElement {
    message;
    xerror;
    handleClick(){
        makeGetCallout()
        .then((result)=> {
            this.message = result;
            this.error = undefined;
        })
        .catch((error)=>{
            this.message = undefined;
            this.xerror = error.body.message;
        });
    }    
  
}